package ECommerceApp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.BinaryOperator;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Home {

	public static void main(String args[]) {
		Set evenNumbers = Stream.of(1, 2, 3, 4, 5, 6, 2, 3, 4).filter(item -> item % 2 == 0)
				.collect(Collectors.toSet());
		System.out.println(evenNumbers);

//		List<Products> productsArr1=null;
//		Set emptyEvenNumbers=productsArr1.stream()
//				.filter(item -> (item.getPrice() )%2 ==0)
//				.collect(Collectors.toSet());
//				System.out.println(evenNumbers);
		int[] arr = { 0, 1, 2, 3, 4, 5, 6 };

		Arrays.stream(arr, 1, 3).forEach(System.out::println);// 1,2;

		Stream.of(1, 2, 3, 4, 5, 6, 2, 3, 4).filter(item -> item % 2 == 0).collect(Collectors.toSet())
				.forEach(System.out::println);

		List<Products> productList = new ArrayList<>();

		productList.add(new Products(1, 1500, 50, 10, "Laptop", "High performance laptop", "Black", "E001"));
		productList.add(new Products(2, 500, 100, 5, "Smartphone", "Latest model smartphone", "Blue", "E002"));
		productList.add(new Products(3, 200, 30, 0, "Headphones", "Noise-cancelling headphones", "Red", "A003"));
		productList.add(new Products(4, 700, 20, 15, "Smartwatch", "Fitness tracking smartwatch", "White", "E004"));
		productList.add(new Products(5, 100, 200, 20, "USB Drive", "32GB USB flash drive", "Silver", "A005"));
		productList
				.add(new Products(6, 300, 80, 10, "Bluetooth Speaker", "Portable Bluetooth speaker", "Green", "A006"));
		productList.add(new Products(7, 1500, 10, 25, "Tablet", "10-inch display tablet", "Gold", "E007"));

		for (Products product : productList) {
			System.out.println(product);
		}
		List<Orders> orderList = new ArrayList<>();

		Map<Integer, Integer> productQuantityMap1 = new HashMap<>();
		productQuantityMap1.put(1, 1); // 1 Laptop
		productQuantityMap1.put(3, 2); // 2 Headphones

		Orders order1 = new Orders(101, "User1", List.of(productList.get(0), productList.get(2)), productQuantityMap1,
				new Date(), "Credit Card", "Paid");

		Map<Integer, Integer> productQuantityMap2 = new HashMap<>();
		productQuantityMap2.put(4, 1); // 1 Smartwatch
		productQuantityMap2.put(5, 3); // 3 USB Drives

		Orders order2 = new Orders(102, "User2", List.of(productList.get(3), productList.get(4)), productQuantityMap2,
				new Date(), "Debit Card", "Pending");

		Map<Integer, Integer> productQuantityMap3 = new HashMap<>();
		productQuantityMap3.put(6, 2); // 2 Bluetooth Speakers
		productQuantityMap3.put(7, 1); // 1 Tablet

		Orders order3 = new Orders(103, "User3", List.of(productList.get(5), productList.get(6)), productQuantityMap3,
				new Date(), "PayPal", "Paid");

		orderList.add(order1);
		orderList.add(order2);
		orderList.add(order3);

		for (Orders order : orderList) {
			System.out.println(order);
		}
		Comparator<Products> byPrice = Comparator.comparingInt(Products::getPrice);
		BinaryOperator<Products> costlierOf = BinaryOperator.maxBy(byPrice);
		Optional<Products> costliestProduct = productList.stream().reduce(costlierOf);
		System.out.println("Costliest product" + costliestProduct);

		productList.stream().filter(item -> item.getPrice() > 500).forEach(System.out::println);
		int totalCost = productList.stream().collect(Collectors.summingInt(Products::getPrice));
		System.out.println("totalCost" + totalCost);

//		maxPricedProduct=productList.stream()
//                .max((p1, p2) -> Integer.compare(p1.price, p2.price));
//		
		Map<Integer, String> productIdNameMap = productList.stream()
				.collect(Collectors.toMap(product -> product.getProductId(), product -> product.getProductName()));
		System.out.println(productIdNameMap);

		List<Products> sortedList = productList.stream().sorted(Comparator.comparingInt(Products::getQuantityInHand))
				.collect(Collectors.toList());
		System.out.println("SortedList" + sortedList);
		productList.stream().sorted(Comparator.comparingInt(Products::getPrice).thenComparing(Products::getProductName))
				.collect(Collectors.toList()).forEach(System.out::println);
		productList.stream()
				.map(product -> Map.of("productId", product.getProductId(), "productName", product.getProductName()))
				.collect(Collectors.toList()).forEach(System.out::println);

	}

}
