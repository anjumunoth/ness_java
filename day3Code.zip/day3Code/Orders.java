package ECommerceApp;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class Orders {
    private int orderId;
    private String userId;
    private List<Products> productsArr;
    private Map<Integer, Integer> productQuantityMap;
    private Date orderDate;
    private String paymentType;
    private String paymentStatus;

    public Orders(int orderId, String userId, List<Products> productsArr, Map<Integer, Integer> productQuantityMap, Date orderDate, String paymentType, String paymentStatus) {
        this.orderId = orderId;
        this.userId = userId;
        this.productsArr = productsArr;
        this.productQuantityMap = productQuantityMap;
        this.orderDate = orderDate;
        this.paymentType = paymentType;
        this.paymentStatus = paymentStatus;
    }

    @Override
    public String toString() {
        return "Orders [orderId=" + orderId + ", userId=" + userId + ", productsArr=" + productsArr + ", productQuantityMap=" + productQuantityMap + ", orderDate=" + orderDate + ", paymentType=" + paymentType + ", paymentStatus=" + paymentStatus + "]";
    }

    // Getters and Setters
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<Products> getProductsArr() {
        return productsArr;
    }

    public void setProductsArr(List<Products> productsArr) {
        this.productsArr = productsArr;
    }

    public Map<Integer, Integer> getProductQuantityMap() {
        return productQuantityMap;
    }

    public void setProductQuantityMap(Map<Integer, Integer> productQuantityMap) {
        this.productQuantityMap = productQuantityMap;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
}
